/* This function marks the start of the farm */
int start_farm()
{
    return 1;
}

unsigned getval_206()
{
    return 2496104776U;
}

void setval_182(unsigned *p)
{
    *p = 3284633928U;
}

void setval_280(unsigned *p)
{
    *p = 1477597871U;
}

unsigned getval_335()
{
    return 2425378874U;
}

unsigned getval_180()
{
    return 2425640997U;
}

unsigned getval_497()
{
    return 3284633928U;
}

unsigned getval_361()
{
    return 3247476824U;
}

unsigned getval_144()
{
    return 3284634440U;
}

/* This function marks the middle of the farm */
int mid_farm()
{
    return 1;
}

/* Add two arguments */
long add_xy(long x, long y)
{
    return x+y;
}

void setval_135(unsigned *p)
{
    *p = 2425409929U;
}

unsigned getval_490()
{
    return 3374370441U;
}

unsigned addval_225(unsigned x)
{
    return x + 3380924043U;
}

void setval_122(unsigned *p)
{
    *p = 3372798344U;
}

unsigned addval_192(unsigned x)
{
    return x + 2425409928U;
}

unsigned getval_496()
{
    return 3269495112U;
}

unsigned getval_134()
{
    return 3375943305U;
}

void setval_320(unsigned *p)
{
    *p = 3281044105U;
}

unsigned getval_428()
{
    return 3676361129U;
}

unsigned addval_325(unsigned x)
{
    return x + 3380137609U;
}

unsigned addval_102(unsigned x)
{
    return x + 3380920969U;
}

void setval_270(unsigned *p)
{
    *p = 3767094409U;
}

unsigned getval_165()
{
    return 3531915977U;
}

void setval_284(unsigned *p)
{
    *p = 3381969545U;
}

void setval_290(unsigned *p)
{
    *p = 2464188744U;
}

void setval_169(unsigned *p)
{
    *p = 3380924809U;
}

void setval_246(unsigned *p)
{
    *p = 3677933195U;
}

unsigned addval_471(unsigned x)
{
    return x + 2496760254U;
}

unsigned getval_119()
{
    return 3223896713U;
}

unsigned getval_103()
{
    return 2447411528U;
}

unsigned getval_429()
{
    return 3507047759U;
}

unsigned addval_219(unsigned x)
{
    return x + 3286273352U;
}

unsigned addval_332(unsigned x)
{
    return x + 2425409163U;
}

unsigned addval_479(unsigned x)
{
    return x + 2430634312U;
}

unsigned getval_151()
{
    return 3224945281U;
}

void setval_141(unsigned *p)
{
    *p = 2429618487U;
}

unsigned addval_311(unsigned x)
{
    return x + 2428684577U;
}

unsigned addval_216(unsigned x)
{
    return x + 2430601544U;
}

void setval_468(unsigned *p)
{
    *p = 3524838025U;
}

void setval_201(unsigned *p)
{
    *p = 3767093332U;
}

unsigned addval_424(unsigned x)
{
    return x + 2463009040U;
}

unsigned addval_436(unsigned x)
{
    return x + 3281047176U;
}

/* This function marks the end of the farm */
int end_farm()
{
    return 1;
}
